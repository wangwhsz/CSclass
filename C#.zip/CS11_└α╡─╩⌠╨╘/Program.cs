﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS11_类的属性
{
    class Program
    {
        static void Main(string[] args)
        {
            Person per = new Person("邵省长",20);
            per.Say();
        }
    }
}
