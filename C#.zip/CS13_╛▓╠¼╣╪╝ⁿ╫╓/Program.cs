﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS13_静态修饰符
{
    class Program
    {
        static void Main(string[] args)
        {
            //Person ps1 = new Person();
            //Person ps2 = new Person();
            //ps1.Say();
            //ps2.Say();

        }
    }
}
